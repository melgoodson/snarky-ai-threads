import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Use service role key to bypass RLS since we verify auth ourselves
  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    console.log("Starting checkout process...");

    // Auth is optional — guests can checkout without signing in
    let userId: string | null = null;
    let userEmail: string | null = null;

    const authHeader = req.headers.get("Authorization");
    if (authHeader) {
      const token = authHeader.replace("Bearer ", "");
      const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);

      if (!authError && user) {
        userId = user.id;
        userEmail = user.email || null;
        console.log("Authenticated user:", userEmail);
      }
    }

    const { cartItems, shippingAddress, guestEmail } = await req.json();

    // Use authenticated email or fall back to guest email from form
    const email = userEmail || guestEmail;
    if (!email) {
      throw new Error("Email is required for checkout");
    }

    if (!cartItems || cartItems.length === 0) {
      throw new Error("Cart is empty");
    }

    console.log("Checkout email:", email, "| User ID:", userId || "GUEST");

    // Calculate total
    const totalAmount = cartItems.reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0);

    // Create order in database FIRST to avoid Stripe metadata size limits
    const { data: orderData, error: orderError } = await supabaseClient
      .from("orders")
      .insert({
        user_id: userId,
        email: email,
        total_amount: totalAmount,
        shipping_address: shippingAddress,
        status: "pending",
      })
      .select()
      .single();

    if (orderError || !orderData) {
      console.error("Failed to create order:", orderError);
      throw new Error("Failed to create order in database");
    }

    console.log("Order created:", orderData.id);

    // Helper to extract URL string from various formats
    const extractUrl = (value: any): string | null => {
      if (!value) return null;
      if (typeof value === 'string') {
        if (value === '[object Object]') return null; // Already stringified object
        return value;
      }
      if (typeof value === 'object') {
        return value.src || value.url || value.image_url || null;
      }
      return null;
    };

    // UUID v4 regex for validation
    const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

    // Create order items
    const origin = req.headers.get("origin") || "https://snarkyasshumans.com";
    const orderItems = cartItems.map((item: any) => {
      // Extract design image URL - ensure it's a string, not an object
      let designUrl = extractUrl(item.designImageUrl) || extractUrl(item.artworkUrl);

      // Fallback to image if it's a valid string URL
      if (!designUrl) {
        const imageUrl = extractUrl(item.image);
        if (imageUrl && !imageUrl.startsWith('data:')) {
          designUrl = imageUrl;
        }
      }

      // Make relative URLs absolute so Printify can access them
      if (designUrl && !designUrl.startsWith('http') && !designUrl.startsWith('data:')) {
        designUrl = `${origin}${designUrl.startsWith('/') ? '' : '/'}${designUrl}`;
      }

      // Validate product_id is a real UUID to avoid FK constraint failures
      const productId = item.productId && UUID_RE.test(item.productId) ? item.productId : null;

      console.log(`Order item: product_id=${productId}, design URL=${designUrl}`);

      return {
        order_id: orderData.id,
        product_id: productId,
        printify_product_id: item.printifyProductId || "placeholder",
        variant_id: item.variantId || "placeholder",
        quantity: item.quantity,
        price: item.price,
        design_image_url: designUrl,
      };
    });

    const { error: itemsError } = await supabaseClient
      .from("order_items")
      .insert(orderItems);

    if (itemsError) {
      console.error("Failed to create order items:", JSON.stringify(itemsError));
      throw new Error(`Failed to create order items: ${itemsError.message || itemsError.code}`);
    }

    console.log("Order items created");

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });

    // Check if customer exists
    const customers = await stripe.customers.list({ email: email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
      console.log("Found existing customer:", customerId);
    }

    // Convert cart items to Stripe line items using dynamic price_data
    // This supports all product types without needing pre-created Stripe price IDs
    const lineItems = cartItems.map((item: any) => {
      const unitAmount = Math.round((Number(item.price) || 0) * 100); // Stripe expects cents

      return {
        price_data: {
          currency: "usd",
          product_data: {
            name: item.title || "Custom Product",
          },
          unit_amount: unitAmount,
        },
        quantity: item.quantity,
      };
    });

    console.log("Line items:", lineItems);

    // Only store order ID in metadata (stays well under 500 char limit)
    const metadata = {
      order_id: orderData.id,
    };

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : email,
      line_items: lineItems,
      mode: "payment",
      success_url: `${req.headers.get("origin")}/order-confirmation/{CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.get("origin")}/checkout`,
      metadata,
    });

    console.log("Checkout session created:", session.id);

    // Store Stripe session ID on the order for admin reference
    await supabaseClient
      .from("orders")
      .update({ stripe_session_id: session.id })
      .eq("id", orderData.id);

    return new Response(JSON.stringify({ url: session.url, sessionId: session.id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    console.error("Error in create-checkout:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
